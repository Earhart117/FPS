README
https://github.com/Earhart117/FPS
Controls:
W - Forward
S - Backwards
A - Move Left
D - Move Right
Q - Add Score
Shift - Sprint
Mouse Left Click - Fire


I was unable to get OBS to record the game sounds, I noticed that after the first recording and tried 
adding it to obs so it would pickup the sounds but I could not get it to pick the audio up on OBS. 

I was having trouble getting the music to play different tracks on the main menu and the first level. 
I think I would have to redo the audio manager without a singlton to do that but I'm not sure.